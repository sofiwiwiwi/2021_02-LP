public interface Enemigo{
    /* 
    Es un método abstracto que está implementado en Monstruo.java
    y JefeFinal.java

    recibe un objeto Jugador y no retrona nada
    */
    public abstract void combate(Jugador jugador);
}
