Nombre: Sofía Isidora Riquelme Flores
ROL: 202073615-4

La tarea se compone de los siguientes archivos:
    • Animal.c
    • Animal.h
    • simulacion.c
    • makefile

Para realizar la compilación se debe estar en una carpeta con todos los archivos mencionados anteriormente y correr en la consola:
    make all

Luego para la posterior ejecución usar:
    make run

Si desea limpiar los archivos creados durante la compilación ejecute el comando:
    make clean


No logré hacer lo de la iteración de tiempo, pero puse una opcion en el menú para reproducir dos animales
