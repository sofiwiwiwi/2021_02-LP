Nombre: Sofía Isidora Riquelme Flores
ROL: 202073615-4
------------------------------------------------------------

La tarea se compone de los siguientes archivos:
codigos.txt
movmariolp.py

Para correrla, en la carpeta utilizar el siguiente comando:
    python movmariolp.py

se creará el archivo errores.txt dentro de la misma carpeta